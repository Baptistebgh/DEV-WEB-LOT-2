package beghindevweb.servlets;

import java.io.IOException;
import java.sql.Blob;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beghindevweb.pojos.Film;
import beghindevweb.services.FilmService;


@WebServlet("/AjoutFilm")
public class AddFilmServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String nomfilm = req.getParameter("nomfilm");
		String realisateur =req.getParameter("realisateur");
		String acteur_principal = req.getParameter("acteur_principal");
		String annee_de_sortie = req.getParameter("annee_de_sortie");
		String synopsis = req.getParameter("synopsis");
		String heros_principal = req.getParameter("heros_principal");
		String note = req.getParameter("note");
		String imgfilm = req.getParameter("imgfilm");
		
		Film filmtoAdd = new Film(null, nomfilm, realisateur, acteur_principal, annee_de_sortie, synopsis, heros_principal,null, null);
		FilmService.getInstance().addFilm(filmtoAdd);
		
		resp.sendRedirect("Film");
	}
	
	 

}
