package beghindevweb.servlets;

import java.io.IOException;
import java.sql.Blob;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import beghindevweb.pojos.Heros;
import beghindevweb.services.HerosService;

@WebServlet("/AjoutHéros")
public class AddHerosServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException { 
		String nomheros= req.getParameter("nomheros");
		String identite_secrete = req.getParameter("identite_secrete");
		String groupe = req.getParameter("groupe");
		String franchise= req.getParameter("franchise");
		String description = req.getParameter("description");
		String acteur_incarnant = req.getParameter("acteur_incarnant");
		String un_film = req.getParameter("un_film");
		String imgheros = req.getParameter("imgheros");
			
		Heros HerostoAdd = new Heros(null, nomheros, identite_secrete, groupe, franchise, description, acteur_incarnant, un_film, null);
		HerosService.getInstance().addHeros(HerostoAdd);
			
		resp.sendRedirect("Héros");

	}
}
