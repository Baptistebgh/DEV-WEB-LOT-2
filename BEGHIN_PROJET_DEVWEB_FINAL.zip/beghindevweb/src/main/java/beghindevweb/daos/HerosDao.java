package beghindevweb.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import beghindevweb.pojos.Heros;

public class HerosDao {

	public static List<Heros> listHeros() {
		List<Heros> listheros = new ArrayList<>(); 
		try {
			Connection connection = DataSourceProvider.getDataSource().getConnection(); 
			PreparedStatement statement = connection.prepareStatement("SELECT * FROM Heros  ORDER BY idheros");
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				listheros.add(new Heros(resultSet.getInt("idheros"), resultSet.getString("nomheros"), resultSet.getString("identite_secrete"), resultSet.getString("groupe"), resultSet.getString("franchise"), resultSet.getString("description"), resultSet.getString("acteur_incarnant"), resultSet.getString("un_film"), resultSet.getBlob("imgheros")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return listheros;
	}
	
	
	public static Heros addHeros(Heros heros) {
		try {
			Connection connection = DataSourceProvider.getDataSource().getConnection(); 
			PreparedStatement statement = connection.prepareStatement("INSERT INTO heros(idheros, nomheros, identite_secrete, groupe, franchise, description, acteur_incarnant, un_film, imgheros) VALUES(?,?,?,?,?,?,?,?,?)");
			statement.setInt(1, heros.getIdheros());
			statement.setString(2, heros.getNomheros());
			statement.setString(3, heros.getIdentite_secrete());
			statement.setString(4, heros.getGroupe());
			statement.setString(5, heros.getFranchise());
			statement.setString(6, heros.getDescription());
			statement.setString(7, heros.getActeur_incarnant());
			statement.setString(8, heros.getUn_film());
			statement.setBlob(9, heros.getImgheros());
			statement.executeUpdate();
			return heros;
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static void deleteHeros(Heros heros){
		try {
			Connection connection = DataSourceProvider.getDataSource().getConnection(); 
			PreparedStatement statement = connection.prepareStatement("DELETE FROM heros WHERE idheros=?");
			statement.setInt(1, Heros.getIdheros());   /** N EST PAS CENSE ETRE STATIQUE **/
			statement.executeUpdate();	
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}
	

	
	public static Heros updateHeros(Heros heros) {
		try {
			Connection connection = DataSourceProvider.getDataSource().getConnection();
			PreparedStatement statement = connection.prepareStatement("UPDATE heros SET idheros=?, nomheros=?, identite_secrete=?, groupe=?, franchise=?, description=?, acteur_incarnant=?, un_film=?, imgheros=? WHERE idheros=?");
			statement.setString(1, heros.getNomheros());
			statement.setString(2, heros.getIdentite_secrete());
			statement.setString(3, heros.getGroupe());
			statement.setString(4, heros.getFranchise());
			statement.setString(5, heros.getDescription());
			statement.setString(6, heros.getActeur_incarnant());
			statement.setString(7, heros.getUn_film());
			statement.setBlob(8, heros.getImgheros());
			statement.executeUpdate();
			return heros;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}

