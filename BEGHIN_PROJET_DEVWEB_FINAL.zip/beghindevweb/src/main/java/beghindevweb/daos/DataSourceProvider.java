package beghindevweb.daos;

import javax.sql.DataSource;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

public class DataSourceProvider {

	protected static DataSource getDataSource(){
		MysqlDataSource dataSource = new MysqlDataSource();
		dataSource.setServerName("localhost");
		dataSource.setPort(3306);
		dataSource.setDatabaseName("projetdevweb");
		dataSource.setUser("root");
		dataSource.setPassword("robinbg");
		
		return dataSource;
	}
	
}
