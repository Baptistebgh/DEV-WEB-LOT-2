package beghindevweb.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import beghindevweb.pojos.Film;

public class FilmDao {

	
	public static List<Film> listFilm() {
		List<Film> films = new ArrayList<>(); 
		try {
			Connection connection = DataSourceProvider.getDataSource().getConnection(); 
			PreparedStatement statement = connection.prepareStatement("SELECT * FROM Film  ORDER BY idfilm");
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				films.add(new Film(resultSet.getInt("idfilm	"), resultSet.getString("nomfilm"), resultSet.getString("realisateur"), resultSet.getString("acteur_principal"), resultSet.getString("annee_de_sortie"), resultSet.getString("synopsis"), resultSet.getString("heros_principal"), resultSet.getInt("note"), resultSet.getBlob("imgfilm")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return films;
	}
	
	
	public static Film addFilm(Film film) {
		try {
			Connection connection = DataSourceProvider.getDataSource().getConnection(); 
			PreparedStatement statement = connection.prepareStatement("INSERT INTO film( idfilm, nomfilm, realisateur, acteur_principal, annee_de_sortie, synopsis, heros_principal, note, imgfilm) VALUES(?,?,?,?,?,?,?,?,?)");
			statement.setInt(1, film.getIdfilm());
			statement.setString(2, film.getNomfilm());
			statement.setString(3, film.getRealisateur());
			statement.setString(4, film.getActeur_principal());
			statement.setString(5, film.getAnnee_de_sortie());
			statement.setString(6, film.getSynopsis());
			statement.setString(7, film.getHeros_principal());
			statement.setInt(8, film.getNote());
			statement.setBlob(9, film.getImgfilm());
			statement.executeUpdate();
			return film;
		}catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static void deleteFilm(Film film){
		try {
			Connection connection = DataSourceProvider.getDataSource().getConnection(); 
			PreparedStatement statement = connection.prepareStatement("DELETE FROM film WHERE idfilm=?");
			statement.setInt(1, Film.getIdfilm());   /** N EST PAS CENSE ETRE STATIQUE **/
			statement.executeUpdate();	
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}
	

	
	public static Film updateFilm(Film film) {
		try {
			Connection connection = DataSourceProvider.getDataSource().getConnection();
			PreparedStatement statement = connection.prepareStatement("UPDATE film SET idfilm=?, nomfilm=?, realisateur=?, acteur_principal=?, annee_de_sortie=?, synopsis=?, heros_principal=?, note=?, imgfilm=? WHERE idfilm=?");
			statement.setString(1, film.getNomfilm());
			statement.setString(2, film.getRealisateur());
			statement.setString(3, film.getActeur_principal());
			statement.setString(4, film.getAnnee_de_sortie());
			statement.setString(5, film.getSynopsis());
			statement.setString(6, film.getHeros_principal());
			statement.setInt(7, film.getNote());
			statement.setBlob(8, film.getImgfilm());
			statement.executeUpdate();
			return film;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}
