	package beghindevweb.pojos;


import java.sql.Blob;

public class Film {
	
	private static Integer idfilm;    /** N EST PAS CENSE ETRE STATIQUE **/
	private String nomfilm;
	private String realisateur;
	private String acteur_principal;
	private String annee_de_sortie;
	private String synopsis;
	private String heros_principal;
	private Integer note;
	private Blob imgfilm;
	
	
	public static Integer getIdfilm() {           /** N EST PAS CENSE ETRE STATIQUE **/
		return idfilm;
	}
	public void setIdfilm(Integer idfilm) {
		this.idfilm = idfilm;
	}
	public String getNomfilm() {
		return nomfilm;
	}
	public void setNomfilm(String nomfilm) {
		this.nomfilm = nomfilm;
	}
	public String getRealisateur() {
		return realisateur;
	}
	public void setRealisateur(String realisateur) {
		this.realisateur = realisateur;
	}
	public String getActeur_principal() {
		return acteur_principal;
	}
	public void setActeur_principal(String acteur_principal) {
		this.acteur_principal = acteur_principal;
	}
	public String getAnnee_de_sortie() {
		return annee_de_sortie;
	}
	public void setAnnee_de_sortie(String annee_de_sortie) {
		this.annee_de_sortie = annee_de_sortie;
	}
	public String getSynopsis() {
		return synopsis;
	}
	public void setSynopsis(String synopsis) {
		this.synopsis = synopsis;
	}
	public String getHeros_principal() {
		return heros_principal;
	}
	public void setHeros_principal(String heros_principal) {
		this.heros_principal = heros_principal;
	}
	public Integer getNote() {
		return note;
	}
	public void setNote(Integer note) {
		this.note = note;
	}
	public Blob getImgfilm() {
		return imgfilm;
	}
	public void setImgfilm(Blob imgfilm) {
		this.imgfilm = imgfilm;
	}
	
	
	public Film(Integer idfilm, String nomfilm, String realisateur, String acteur_principal, String annee_de_sortie,
			String synopsis, String heros_principal, Integer note, Blob imgfilm) {
		super();
		this.idfilm = idfilm;
		this.nomfilm = nomfilm;
		this.realisateur = realisateur;
		this.acteur_principal = acteur_principal;
		this.annee_de_sortie = annee_de_sortie;
		this.synopsis = synopsis;
		this.heros_principal = heros_principal;
		this.note = note;
		this.imgfilm = imgfilm;
	}
	
	
	
	
	
	
}
