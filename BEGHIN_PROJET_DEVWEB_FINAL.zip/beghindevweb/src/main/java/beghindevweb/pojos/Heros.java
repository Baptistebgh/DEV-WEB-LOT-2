package beghindevweb.pojos;

import java.awt.Image;
import java.sql.Blob;

public class Heros {

	private static Integer idheros;     /** N EST PAS CENSE ETRE STATIQUE **/
	private String nomheros;
	private String identite_secrete;
	private String groupe;
	private String franchise;
	private String description;
	private String acteur_incarnant;
	private String un_film;
	private Blob imgheros;
	
	
	public static Integer getIdheros() {              /** N EST PAS CENSE ETRE STATIQUE **/
		return idheros;
	}
	
	public void setIdheros(Integer idheros) {
		this.idheros = idheros;                    
	}
	public String getNomheros() {
		return nomheros;
	}
	public void setNomheros(String nomheros) {
		this.nomheros = nomheros;
	}
	public String getIdentite_secrete() {
		return identite_secrete;
	}
	public void setIdentite_secrete(String identite_secrete) {
		this.identite_secrete = identite_secrete;
	}
	public String getGroupe() {
		return groupe;
	}
	public void setGroupe(String groupe) {
		this.groupe = groupe;
	}
	public String getFranchise() {
		return franchise;
	}
	public void setFranchise(String franchise) {
		this.franchise = franchise;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getActeur_incarnant() {
		return acteur_incarnant;
	}
	public void setActeur_incarnant(String acteur_incarnant) {
		this.acteur_incarnant = acteur_incarnant;
	}
	public String getUn_film() {
		return un_film;
	}
	public void setUn_film(String un_film) {
		this.un_film = un_film;
	}
	public Blob getImgheros() {
		return imgheros;
	}
	public void setImgheros(Blob imgheros) {
		this.imgheros = imgheros;
	}
	
	
	public Heros(Integer idheros, String nomheros, String identite_secrete, String groupe, String franchise,
			String description, String acteur_incarnant, String un_film, Blob imgheros) {
		super();
		this.idheros = idheros;
		this.nomheros = nomheros;
		this.identite_secrete = identite_secrete;
		this.groupe = groupe;
		this.franchise = franchise;
		this.description = description;
		this.acteur_incarnant = acteur_incarnant;
		this.un_film = un_film;
		this.imgheros = imgheros;
	}
	
	
	
	
}
