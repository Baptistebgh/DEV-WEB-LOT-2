package beghindevweb.services;

import java.util.List;

import beghindevweb.daos.HerosDao;
import beghindevweb.pojos.Heros;

public class HerosService {

	private HerosDao herosDao = new HerosDao();
	
	private static class HerosServiceHolder {
		private static HerosService instance = new HerosService(); 
	}
	
	public static HerosService getInstance(){
		return HerosServiceHolder.instance;
	}
	
	private HerosService(){
	}
	
	public List<Heros> listHeros(){
		return herosDao.listHeros();
	}
	
	public Heros addHeros(Heros heros){
		return herosDao.addHeros(heros);
	};
	
	public void deleteHeros(Heros heros){
		herosDao.deleteHeros(heros);
	};
	
	public Heros updateHeros(Heros heros){
		return herosDao.updateHeros(heros);
	}
}
