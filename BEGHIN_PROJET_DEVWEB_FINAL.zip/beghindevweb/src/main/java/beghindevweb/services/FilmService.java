package beghindevweb.services;

import java.util.List;

import beghindevweb.daos.FilmDao;
import beghindevweb.pojos.Film;

public class FilmService {
	
	private FilmDao filmDao = new FilmDao();
	
	private static class FilmServiceHolder {
		private static FilmService instance = new FilmService(); 
	}
	
	public static FilmService getInstance(){
		return FilmServiceHolder.instance;
	}
	
	private FilmService(){
	}
	
	public List<Film> listFilm(){
		return filmDao.listFilm();
	}
	
	public Film addFilm(Film film){
		return filmDao.addFilm(film);
	};
	
	public void deleteFilm(Film film){
		filmDao.deleteFilm(film);
	};
	
	public Film updateFilm(Film film){
		return filmDao.updateFilm(film);
	}
	
	
}
