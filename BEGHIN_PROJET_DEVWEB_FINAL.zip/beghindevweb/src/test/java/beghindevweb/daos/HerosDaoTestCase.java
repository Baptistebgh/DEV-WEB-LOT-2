package beghindevweb.daos;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;

import beghindevweb.pojos.Heros;

public class HerosDaoTestCase {

	private HerosDao herosDao = new HerosDao();

	@Before
	public void initDb() throws Exception {
		try (
			Connection connection = DataSourceProvider.getDataSource().getConnection();
			Statement stmt = connection.createStatement()){
			stmt.executeUpdate("DELETE FROM heros");
			stmt.executeUpdate("INSERT INTO heros(idheros, nomheros, identite_secrete, groupe, franchise, description, acteur_incarnant, un_film, imgheros) VALUES (10, 'Captain America', 'Steve Rogers', 'Avengers', 'Marvel','Ce super-héros, incarnant le patriotisme américain, est emblématique de l'Amérique depuis le début de la Seconde Guerre mondiale, se faisant le porte-drapeau de ses valeurs et étant perçu comme un défenseur du monde libre contre les tyrannies, notamment le régime nazi, contre lequel il fut créé en réaction par ses auteurs.', 'Chris Evans', 'Avengers','')");
			stmt.executeUpdate("INSERT INTO heros(idheros, nomheros, identite_secrete, groupe, franchise, description, acteur_incarnant, un_film, imgheros) VALUES (14, 'Doctor Strange', 'Stephen Strange', '', 'Marvel, 'Pour combattre les forces du mal, Strange fonde bientôt le groupe des Défenseurs qui réunit à ses côtés Hulk, Namor le prince des mers et le Surfer d'Argent.', 'Benedict Cumberbatch', 'Doctor Strange','')");
		}
	}
	
	@Test
	public void shouldListHeros() {
		// WHEN
		List<Heros> listheros = HerosDao.listHeros();
		// THEN
		Assertions.assertThat(listheros).hasSize(2);
		Assertions.assertThat(listheros).extracting("nomheros").containsExactly("Captain America","Doctor Strange");
		Assertions.assertThat(listheros).extracting("groupe").containsExactly("Avengers", "");
		Assertions.assertThat(listheros).extracting("franchise").containsExactly("Marvel", "Marvel");
	}
	
	@Test
	public void shouldAddHeros() throws Exception {
		// GIVEN
		Blob imgheros = null;
		Heros herosToAdd = new Heros(25, "Spiderman", "Peter Parker", "", "Marvel", "Un jour, à la suite d'une expérience à laquelle il assiste, il est mordu par une araignée radioactive. Cette morsure lui confère des super-pouvoirs : une force et une agilité hors du commun, la capacité d’adhérer aux parois ainsi qu'un « sens d'araignée » l'avertissant des dangers imminents.", "Tobey Maguire", "Spider-Man", imgheros );
		// WHEN
		Heros herosAdded = HerosDao.addHeros(herosToAdd);
		// THEN
		Assertions.assertThat(herosAdded.getNomheros()).isEqualTo("Spiderman");
		Assertions.assertThat(herosAdded.getActeur_incarnant()).isEqualTo("Tobey Maguire");
		Assertions.assertThat(herosAdded.getGroupe()).isEqualTo("");
		try (Connection connection = DataSourceProvider.getDataSource().getConnection();
				PreparedStatement stmt = connection.prepareStatement("SELECT * FROM heros WHERE idheros = ?")) {
			stmt.setInt(1, herosAdded.getIdheros());
			try (ResultSet rs = stmt.executeQuery()) {
				Assertions.assertThat(rs.next()).isTrue();
				Assertions.assertThat(rs.getString("nomheros")).isEqualTo(herosAdded.getNomheros());
				Assertions.assertThat(rs.getString("description")).isEqualTo(herosAdded.getDescription());
				Assertions.assertThat(rs.getString("groupe")).isEqualTo(herosAdded.getGroupe());
				Assertions.assertThat(rs.next()).isFalse();
			}
		}
	}
	
	@Test
	public void shouldDeleteHeros() throws Exception {
		// GIVEN
		Blob imgheros = null;
		Heros heros = new Heros(25, "Spiderman", "Peter Parker", "", "Marvel", "Un jour, à la suite d'une expérience à laquelle il assiste, il est mordu par une araignée radioactive. Cette morsure lui confère des super-pouvoirs : une force et une agilité hors du commun, la capacité d’adhérer aux parois ainsi qu'un « sens d'araignée » l'avertissant des dangers imminents.", "Tobey Maguire", "Spider-Man", imgheros );
		// WHEN
		HerosDao.deleteHeros(heros);
		List<Heros> listHeros = HerosDao.listHeros();
		//THEN
		Assertions.assertThat(listHeros).hasSize(2);
	}
	
	@Test
	public void shouldUpdateHeros() throws Exception {
		// GIVEN
		Blob imgheros = null;
		Heros heros = new Heros(4, "HerosTest", "a", "b", "c", "d","e","f", imgheros);
		// WHEN
		Heros herosUpdated = HerosDao.updateHeros(heros);
		//THEN
		Assertions.assertThat(herosUpdated.getNomheros()).isEqualTo("HerosTest");
		Assertions.assertThat(herosUpdated.getDescription()).isEqualTo("e");
		Assertions.assertThat(herosUpdated.getIdentite_secrete()).isEqualTo("b");
	}
	
}
