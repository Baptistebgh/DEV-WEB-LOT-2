package beghindevweb.daos;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Before;
import org.junit.Test;

import beghindevweb.pojos.Film;

public class FilmDaoTestCase {

		private FilmDao filmDao = new FilmDao();

		@Before
		public void initDb() throws Exception {
			try (
				Connection connection = DataSourceProvider.getDataSource().getConnection();
				Statement stmt = connection.createStatement()){
				stmt.executeUpdate("DELETE FROM film");
				stmt.executeUpdate("INSERT INTO film(idfilm, nomfilm, realisateur, acteur_principal, annee_de_sortie, synopsis, heros_principal, note, imgfilm) VALUES (1, 'AntMan', 'Peyton Reed', 'Paul Rudd', '2015', 'er en héros et aider son mentor, le Dr Hank Pym, à protéger le secret de son spectaculaire costume d’Ant-Man, afin d’affronter une effroyable menace…', 'Ant Man', 4,'')");
				stmt.executeUpdate("INSERT INTO film(idfilm, nomfilm, realisateur, acteur_principal, annee_de_sortie, synopsis, heros_principal, note, imgfilm) VALUES (4, 'Batman', 'Tim Burton', 'Michael Keaton', '1989', 'Le célèbre et impitoyable justicier, Batman, est de retour. Plus beau, plus fort et plus dépoussiéré que jamais, il s apprête à nettoyer Gotham City et à affronter le terrible Joker…', 'Batman', 4,'')");
			}
		}
		
		@Test
		public void shouldListFilm() {
			// WHEN
			List<Film> films = filmDao.listFilm();
			// THEN
			Assertions.assertThat(films).hasSize(2);
			Assertions.assertThat(films).extracting("acteur_principal").containsExactly("Paul Rudd","Michael Keaton");
			Assertions.assertThat(films).extracting("annee_de_sortie").containsExactly("2015", "1989");
			Assertions.assertThat(films).extracting("note").containsExactly(4, 4);
		}
		
		@Test
		public void shouldAddFilm() throws Exception {
			// GIVEN
			Blob imgfilm = null;
			Film filmToAdd = new Film(19, "Deadpool", "Tim Miller", "Ryan Reynolds", "2016", "Deadpool, est l'anti-héros le plus atypique de l'univers Marvel. A l'origine, il s'appelle Wade Wilson : un ancien militaire des Forces Spéciales devenu mercenaire. Après avoir subi une expérimentation hors norme qui va accélérer ses pouvoirs de guérison, il va devenir Deadpool. Armé de ses nouvelles capacités et d'un humour noir survolté, Deadpool va traquer l'homme qui a bien failli anéantir sa vie.", "Deadpool", 4, imgfilm );
			// WHEN
			Film filmAdded = FilmDao.addFilm(filmToAdd);
			// THEN
			Assertions.assertThat(filmAdded.getNomfilm()).isEqualTo("Deadpool");
			Assertions.assertThat(filmAdded.getSynopsis()).isEqualTo("Deadpool, est l'anti-héros le plus atypique de l'univers Marvel. A l'origine, il s'appelle Wade Wilson : un ancien militaire des Forces Spéciales devenu mercenaire. Après avoir subi une expérimentation hors norme qui va accélérer ses pouvoirs de guérison, il va devenir Deadpool. Armé de ses nouvelles capacités et d'un humour noir survolté, Deadpool va traquer l'homme qui a bien failli anéantir sa vie.");
			Assertions.assertThat(filmAdded.getRealisateur()).isEqualTo("Tim Miller");
			try (Connection connection = DataSourceProvider.getDataSource().getConnection();
					PreparedStatement stmt = connection.prepareStatement("SELECT * FROM film WHERE idfilm = ?")) {
				stmt.setInt(1, filmAdded.getIdfilm());
				try (ResultSet rs = stmt.executeQuery()) {
					Assertions.assertThat(rs.next()).isTrue();
					Assertions.assertThat(rs.getString("nomFilm")).isEqualTo(filmAdded.getNomfilm());
					Assertions.assertThat(rs.getString("synopsis")).isEqualTo(filmAdded.getSynopsis());
					Assertions.assertThat(rs.getString("realisateur")).isEqualTo(filmAdded.getRealisateur());
					Assertions.assertThat(rs.next()).isFalse();
				}
			}
		}
		
		@Test
		public void shouldDeleteFilm() throws Exception {
			// GIVEN
			Blob imgfilm = null;
			Film film = new Film(19, "Deadpool", "Tim Miller", "Ryan Reynolds", "2016", "Deadpool, est l'anti-héros le plus atypique de l'univers Marvel. A l'origine, il s'appelle Wade Wilson : un ancien militaire des Forces Spéciales devenu mercenaire. Après avoir subi une expérimentation hors norme qui va accélérer ses pouvoirs de guérison, il va devenir Deadpool. Armé de ses nouvelles capacités et d'un humour noir survolté, Deadpool va traquer l'homme qui a bien failli anéantir sa vie.", "Deadpool", 4, imgfilm );
			// WHEN
			FilmDao.deleteFilm(film);
			List<Film> films = FilmDao.listFilm();
			//THEN
			Assertions.assertThat(films).hasSize(2);
		}
		
		@Test
		public void shouldUpdateFilm() throws Exception {
			// GIVEN
			Blob imgfilm = null;
			Film film = new Film(4, "FilmTest", "a", "b", "c", "d","e", 4, imgfilm);
			// WHEN
			Film filmUpdated = FilmDao.updateFilm(film);
			//THEN
			Assertions.assertThat(filmUpdated.getNomfilm()).isEqualTo("FilmTest");
			Assertions.assertThat(filmUpdated.getSynopsis()).isEqualTo("e");
			Assertions.assertThat(filmUpdated.getRealisateur()).isEqualTo("b");
		}
		
}

